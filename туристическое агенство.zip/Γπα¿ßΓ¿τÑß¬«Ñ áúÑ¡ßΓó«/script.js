script>
  // === STATE ===
  let state = {
    base: { eco:0, std:0, lux:0 },
    final: { eco:0, std:0, lux:0 },
    eventApplied: false,
    eventMod: 0,
    step: 1
  };

  // === NAV ===
  function nextStep(n) {
    if(n===4 && !state.base.eco) { calcBase(); }
    if(n===5 && !state.final.eco) { calcFinal(); }
    state.step = n;
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
    document.getElementById('step'+n).classList.add('active');
    document.querySelectorAll('.step-btn').forEach((b,i) => {
      b.classList.toggle('active', i+1===n);
    });
    if(n===4) renderChart();
  }

  function goStep(n) { nextStep(n); }

  // === CALCULATIONS ===
  function calcBase() {
    const d = parseInt(document.getElementById('days').value) || 7;
    const get = (id) => parseFloat(document.getElementById(id).value) || 0;
    
    state.base.eco = get('ecoFlight') + get('ecoHotel')*d + get('ecoExc') + get('ecoMeal')*d;
    state.base.std = get('stdFlight') + get('stdHotel')*d + get('stdExc') + get('stdMeal')*d;
    state.base.lux = get('luxFlight') + get('luxHotel')*d + get('luxExc') + get('luxMeal')*d;
    
    alert(`Базовая стоимость (на 1 чел.):\nЭконом: ${state.base.eco} ₽\nСтандарт: ${state.base.std} ₽\nЛюкс: ${state.base.lux} ₽`);
    nextStep(3);
  }

  function calcFinal() {
    const ins = parseFloat(document.getElementById('insRate').value)/100 || 0;
    const sov = parseFloat(document.getElementById('sovRate').value)/100 || 0;
    const tax = parseFloat(document.getElementById('taxRate').value)/100 || 0;
    const mod = 1 + (state.eventApplied ? state.eventMod : 0);

    ['eco','std','lux'].forEach(k => {
      let base = state.base[k];
      let extra = base * (ins + sov + tax);
      state.final[k] = Math.round((base + extra) * mod);
    });

    renderResults();
    renderChart();
    nextStep(4);
  }

  function renderResults() {
    const r = (id, obj, name) => {
      document.getElementById(id).innerHTML = `
        <h3>${name}</h3>
        <table>
          <tr><td>Базовая стоимость</td><td>${obj.base.toLocaleString()} ₽</td></tr>
          <tr><td>Доп. расходы (${((parseFloat(document.getElementById('insRate').value)+parseFloat(document.getElementById('sovRate').value)+parseFloat(document.getElementById('taxRate').value))).toFixed(0)}%)</td><td>${(obj.base * (parseFloat(document.getElementById('insRate').value)+parseFloat(document.getElementById('sovRate').value)+parseFloat(document.getElementById('taxRate').value))/100).toFixed(0)} ₽</td></tr>
          ${state.eventApplied ? `<tr><td>Событие (${state.eventMod>0?'+':''}${(state.eventMod*100).toFixed(0)}%)</td><td>${state.eventMod>0?'+':''}${(obj.base*state.eventMod).toFixed(0)} ₽</td></tr>` : ''}
          <tr class="total"><td>ИТОГО</td><td>${obj.final.toLocaleString()} ₽</td></tr>
        </table>
      `;
    };
    r('ecoResult', {base: state.base.eco, final: state.final.eco}, '🟦 Эконом');
    r('stdResult', {base: state.base.std, final: state.final.std}, '🟩 Стандарт');
    r('luxResult', {base: state.base.lux, final: state.final.lux}, '🟨 Люкс');
  }

  // === DICE & EVENTS ===
  const events = [
    { txt: "✈️ Акция авиакомпании! Скидка 10% на билеты.", type: "percent", val: -0.10, q: "Сколько ₽ составит скидка, если база тура 40 000 ₽?", a: 4000 },
    { txt: "🌧️ Дождливая погода. Придётся добавить 1500 ₽ на развлечения в помещении.", type: "fixed", val: 1500, q: "Какой процент от базы 30 000 ₽ составляет 1500 ₽? (в десятичной дроби)", a: 0.05 },
    { txt: "🎁 Выиграли лотерею! Бонус 5% к бюджету.", type: "percent", val: -0.05, q: "Чему равен 1% от 45 000 ₽?", a: 450 },
    { txt: "📈 Рост цен на топливо. +8% к транспортным расходам.", type: "percent", val: 0.08, q: "Вычислите 8% от 12 000 ₽", a: 960 },
    { txt: "🏨 Отель дал скидку 2000 ₽ за раннее бронирование.", type: "fixed", val: -2000, q: "Сколько будет 2000 от 50000? (в %) Ответ: 4%", a: 4 },
    { txt: "💡 Ничего не произошло. Бюджет без изменений.", type: "none", val: 0, q: "", a: 0 }
  ];

  function rollEvent() {
    const box = document.getElementById('eventBox');
    const dice = document.getElementById('dice1');
    dice.style.animation = "shake 0.5s";
    setTimeout(()=>{
      const ev = events[Math.floor(Math.random()*events.length)];
      state.eventApplied = false;
      state.eventMod = 0;
      
      document.getElementById('eventText').textContent = ev.txt;
      document.getElementById('mathTask').style.display = ev.type==='none'?'none':'block';
      document.getElementById('mathTask').textContent = ev.type==='none'?'Бросьте снова или перейдите к расчётам.' : `Решите, чтобы применить: ${ev.q}`;
      document.getElementById('eventAns').value = '';
      document.getElementById('eventResult').textContent = '';
      box.style.display = ev.type==='none'?'block':'block';
      
      if(ev.type==='none') {
        document.getElementById('eventResult').textContent = "✅ Бюджет без изменений";
        state.eventApplied = true; state.eventMod = 0;
      }
    }, 500);
  }

  function checkEvent() {
    const ev = events.find(e => document.getElementById('eventText').textContent.includes(e.txt));
    if(!ev || ev.type==='none') return;
    let ans = parseFloat(document.getElementById('eventAns').value);
    let correct = ev.a;
    
    // Allow small floating tolerance
    let ok = false;
    if(Math.abs(ans - correct) < 1) ok = true;
    if(ev.type==='percent' && Math.abs((ans/correct) - 1) < 0.05) ok = true;

    if(ok) {
      document.getElementById('eventResult').innerHTML = '<span style="color:var(--success)">✅ Верно! Бонус/штраф применён.</span>';
      state.eventApplied = true;
      state.eventMod = ev.val;
    } else {
      document.getElementById('eventResult').innerHTML = '<span style="color:var(--danger)">❌ Ошибка. Событие не применено.</span>';
    }
  }

  // === CHART ===
  function renderChart() {
    const canvas = document.getElementById('pieChart');
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0,0,canvas.width,canvas.height);
    
    const d = parseInt(document.getElementById('days').value)||7;
    const get = (id)=>parseFloat(document.getElementById(id).value)||0;
    let base = state.base.std;
    let flight = get('stdFlight');
    let hotel = get('stdHotel')*d;
    let exc = get('stdExc');
    let meal = get('stdMeal')*d;
    
    if(base<=0) { ctx.fillText('Введите данные', 100, 150); return; }

    const data = [
      {val: flight, color: '#3b82f6', label: 'Билеты'},
      {val: hotel, color: '#10b981', label: 'Отель'},
      {val: exc, color: '#f59e0b', label: 'Экскурсии'},
      {val: meal, color: '#ef4444', label: 'Питание'}
    ];

    let total = data.reduce((s,i)=>s+i.val,0);
    let start = 0;
    const cx = canvas.width/2, cy = canvas.height/2, r = 100;

    data.forEach(slice => {
      const angle = (slice.val/total)*2*Math.PI;
      ctx.beginPath();
      ctx.moveTo(cx,cy);
      ctx.arc(cx,cy,r,start,start+angle);
      ctx.fillStyle = slice.color;
      ctx.fill();
      start += angle;
    });

    // Legend
    ctx.fillStyle = '#1e293b';
    ctx.font = '12px sans-serif';
    let ly = 20;
    data.forEach(s => {
      ctx.fillStyle = s.color;
      ctx.fillRect(220, ly, 12, 12);
      ctx.fillStyle = '#333';
      ctx.fillText(`${s.label}: ${((s.val/total)*100).toFixed(0)}%`, 238, ly+10);
      ly += 20;
    });
  }

  // === REPORT & EXPORT ===
  function generatePassport() {
    const d = parseInt(document.getElementById('days').value)||7;
    const dest = document.getElementById('dest').value;
    const tr = parseInt(document.getElementById('travelers').value)||1;
    const date = new Date().toLocaleString('ru-RU');
    
    let table = `<table>
      <tr><th>Статья расходов</th><th>Эконом</th><th>Стандарт</th><th>Люкс</th></tr>
      <tr><td>Билеты</td><td>${state.base.eco * (parseFloat(document.getElementById('ecoFlight').value)||0) / (parseFloat(document.getElementById('ecoFlight').value) + (parseFloat(document.getElementById('ecoHotel').value)*d) + (parseFloat(document.getElementById('ecoExc').value)) + (parseFloat(document.getElementById('ecoMeal').value)*d))}</td><td>${state.base.std * (parseFloat(document.getElementById('stdFlight').value)||0) / (parseFloat(document.getElementById('stdFlight').value) + (parseFloat(document.getElementById('stdHotel').value)*d) + (parseFloat(document.getElementById('stdExc').value)) + (parseFloat(document.getElementById('stdMeal').value)*d))}</td><td>${state.base.lux * (parseFloat(document.getElementById('luxFlight').value)||0) / (parseFloat(document.getElementById('luxFlight').value) + (parseFloat(document.getElementById('luxHotel').value)*d) + (parseFloat(document.getElementById('luxExc').value)) + (parseFloat(document.getElementById('luxMeal').value)*d))}</td></tr>`;
    // Simplified for robustness in auto-gen
    table = `<table>
      <tr><th>Категория</th><th>Базовая (₽)</th><th>Доп. расходы (%)</th><th>Событие</th><th>ИТОГО (₽)</th></tr>
      <tr><td>Эконом</td><td>${state.base.eco.toLocaleString()}</td><td>${(parseFloat(document.getElementById('insRate').value)+parseFloat(document.getElementById('sovRate').value)+parseFloat(document.getElementById('taxRate').value))}%</td><td>${state.eventApplied?'Применён':'Нет'}</td><td><b>${state.final.eco.toLocaleString()}</b></td></tr>
      <tr><td>Стандарт</td><td>${state.base.std.toLocaleString()}</td><td>${(parseFloat(document.getElementById('insRate').value)+parseFloat(document.getElementById('sovRate').value)+parseFloat(document.getElementById('taxRate').value))}%</td><td>${state.eventApplied?'Применён':'Нет'}</td><td><b>${state.final.std.toLocaleString()}</b></td></tr>
      <tr><td>Люкс</td><td>${state.base.lux.toLocaleString()}</td><td>${(parseFloat(document.getElementById('insRate').value)+parseFloat(document.getElementById('sovRate').value)+parseFloat(document.getElementById('taxRate').value))}%</td><td>${state.eventApplied?'Применён':'Нет'}</td><td><b>${state.final.lux.toLocaleString()}</b></td></tr>
    </table>`;

    const preview = document.getElementById('reportPreview');
    preview.innerHTML = `
      <h1>📜 Паспорт тура: ${dest}</h1>
      <p><b>Агентство:</b> Алгебра и Ко | <b>Дата формирования:</b> ${date}<br>
      <b>Длительность:</b> ${d} дней | <b>Группа:</b> ${tr} чел.</p>
      
      <h2>1. Цель проекта</h2>
      <p>Научиться применять математические навыки (проценты, пропорции, таблицы, анализ данных) для планирования бюджета и выбора оптимального туристического маршрута.</p>
      
      <h2>2. Смета расходов</h2>
      ${table}
      
      <h2>3. Математические формулы</h2>
      <ul>
        <li>Базовая стоимость = Билеты + (Отель × дни) + Экскурсии + (Питание × дни)</li>
        <li>Дополнительные расходы = База × (Страховка% + Сувениры% + Комиссия%)</li>
        <li>Итоговая цена = (База + Доп.) × (1 ± % от события)</li>
        <li>Соотношение цены и качества: ΔЦены / ΔКомфорта (сравнительный анализ)</li>
      </ul>
      
      <h2>4. Вывод</h2>
      <p>На основе расчётов, вариант «Стандарт» является оптимальным. При переплате всего ~${(((state.final.std-state.final.eco)/state.final.eco)*100).toFixed(0)}% по сравнению с «Экономом», туристы получают проживание классом выше, расширенную экскурсионную программу и комфортное питание. Это демонстрирует принцип «золотой середины» в экономике.</p>
      
      <h2>5. Рефлексия (для заполнения)</h2>
      <p>1. Трудности при сборе реальных цен: _________________________________________</p>
      <p>2. Как изменились бы расчёты при изменении курса валют/инфляции: __________________</p>
      <p>3. Самый важный навык из математики: _________________________________________</p>
      <p>4. Захотелось ли отправиться в путешествие по этому маршруту: ____________________</p>
      
      <p style="margin-top:30px; text-align:center; color:#666; font-size:12px;">Проект по математике | 8 класс</p>
    `;
    document.getElementById('passportBox').innerHTML = `<p>✅ Паспорт сформирован. Проверьте вкладку «Отчёт» или нажмите кнопку экспорта.</p>`;
    preview.style.display = 'block';
  }

  async function exportPDF() {
    if(!document.getElementById('reportPreview').innerHTML) { generatePassport(); await new Promise(r=>setTimeout(r,500)); }
    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF();
    const canvas = await html2canvas(document.getElementById('reportPreview'), {scale: 2});
    const img = canvas.toDataURL('image/png');
    const imgW = 210, pageH = 297;
    const imgH = canvas.height * imgW / canvas.width;
    let pos=0, hLeft=imgH;
    pdf.addImage(img, 'PNG', 0, pos, imgW, imgH);
    hLeft -= pageH;
    while(hLeft>=0){ pos=hLeft-imgH; pdf.addPage(); pdf.addImage(img, 'PNG', 0, pos, imgW, imgH); hLeft-=pageH; }
    pdf.save('tour_agency_report.pdf');
  }

  function exportWord() {
    if(!document.getElementById('reportPreview').innerHTML) generatePassport();
    const h = "<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'><head><meta charset='utf-8'><style>body{font-family:Arial;font-size:12px}table{border-collapse:collapse;width:100%}th,td{border:1px solid #ccc;padding:6px}th{background:#1e3a8a;color:white}</style></head><body>";
    const blob = new Blob([h + document.getElementById("reportPreview").innerHTML + "</body></html>"], {type: 'application/msword'});
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'tour_agency_report.doc'; a.click();
  }

  window.onload = () => goStep(1);